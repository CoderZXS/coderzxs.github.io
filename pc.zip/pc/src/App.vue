<template>
  <my-header v-show="$route.meta.isShowHeader"></my-header>
  <router-view></router-view>
  <my-footer v-show="$route.meta.isShowFooter"></my-footer>
</template>

<script>
import MyHeader from '@/components/Header'
import MyFooter from '@/components/Footer'
export default {
  name: 'App',
  components: {
    MyHeader,
    MyFooter
  },
  methods: {

  }
}
</script>

<style lang="less" scoped>

</style>
