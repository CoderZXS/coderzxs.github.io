import Mock from "mockjs";
import banner from "./banner.json";
import business from "./business.json";
import project from "./project.json";
import company from "./company.json";

Mock.mock("/mock/banner", { code: 200, data: banner, message: "success" });
Mock.mock("/mock/business", { code: 200, data: business, message: "success" });
Mock.mock("/mock/project", { code: 200, data: project, message: "success" });
Mock.mock("/mock/company", { code: 200, data: company, message: "success" });

