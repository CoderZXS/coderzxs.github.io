import request from "./request";
import mockRequest from "./mockRequest";
/*****首页*****/
//获取轮播图接口
export const reqBannerList = () => mockRequest({ url: "/banner", method: "get" });

//获取业务类型接口
export const reqBusinessList = () => mockRequest({ url: "/business", method: "get" });

//获取项目列表接口
export const reqProjectList = () => mockRequest({ url: "/project", method: "get" });

//获取工作经历接口
export const reqCompanyList = () => mockRequest({ url: "/company", method: "get" });
