import axios from "axios";
import nProgress from "nprogress";
import 'nprogress/nprogress.css'
nProgress.configure({showSpinner:false})
let service = axios.create({
    baseURL:'/mock',
    timeout:5000
})

service.interceptors.request.use((config)=>{
    nProgress.start()
    return config
})

service.interceptors.response.use((res)=>{
    nProgress.done()
    return res.data
},(error)=>{
    nProgress.done()
    return new Promise()
})

export default service