// import Vuex from 'vuex'
// import Vue from 'vue'
// import home from '@/store/Home'
// import search from '@/store/Search'
// import detail from '@/store/Detail'
// import shopcart from '@/store/Shopcart'
// import trade from '@/store/Trade'
// Vue.use(Vuex)

// const store = new Vuex.Store({
//     modules:{
//         home,
//         search,
//         detail,
//         shopcart,
//         trade
//     }
// })
// export default store