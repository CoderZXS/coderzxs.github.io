const home = () => import("@/views/Home")

export default [
  {
    path: "/",
    redirect: "/home",
  },
  {
    path: "/home",
    name: "home",
    component: home,
    meta: {
      isShowHeader: true,
      isShowFooter: true,
    },
  }
];
