<template>
    <div class="footer">
        <div class="footer-wrapper">
            <h1 class="title">CoderZXS</h1>
            <el-row>
                <el-col :xs="24" :sm="24" :md="12" :lg="12" :xl="12">
                    <dl>
                        <dt>联系方式</dt>
                        <dd class="item">地址：深圳南山区深圳湾创新科技中心</dd>
                        <dd class="item">电话：17788767570</dd>
                        <dd class="item">邮件：CoderZXS@foxmail.com</dd>
                    </dl>
                </el-col>
                <el-col :xs="24" :sm="24" :md="12" :lg="12" :xl="12">
                    <el-row>
                        <el-col :xs="24" :sm="24" :md="12" :lg="12" :xl="12">
                            <div class="qrcode-item">
                                <img src="../../assets/images/weixin.png" class="img" />
                                <span>微信号:ashun8080</span>
                            </div>
                        </el-col>
                        <el-col :xs="24" :sm="24" :md="12" :lg="12" :xl="12">
                            <div class="qrcode-item">
                                <img src="../../assets/images/douyin.png" class="img" />
                                <span>抖音号:CoderZXS</span>
                            </div>
                        </el-col>
                    </el-row>
                </el-col>
            </el-row>
        </div>
        <div class="bottom-bar">
            <span>Copyright @CoderZXS 版权所有</span>
        </div>
    </div>
</template>

<script>
export default {
    name: 'Footer',
}
</script>

<style scoped lang="less">
.footer {
    color: white;
    background-color: #409EFF;
    font-size: 14px;

    .footer-wrapper {
        width: 100%;
        border-bottom: 1px solid rgba(255, 255, 255, 0.25);
        box-sizing: border-box;
        max-width: 1200px;
        padding: 40px 24px 20px 24px;
        margin: auto;

        .title {
            height: 40px;
            font-size: 18px;
            margin-bottom: 24px;
        }

        .item {
            margin: 10px 0px;
        }

        .qrcode-item {
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            align-items: center;
            margin-top: 10px;

            .img {
                width: 150px;
                height: 150px;
                display: block;
                margin-bottom: 5px;
            }
        }
    }

    .bottom-bar {
        text-align: center;
        padding: 10px 0;
        margin: 0;
        font-size: 16px;
        width: 100%;
    }
}
</style>