<template>
    <div class="header">
        <h1 class="logo-wrapper">
            <router-link to="/home">
                <span class="title">CoderZXS</span>
            </router-link>
        </h1>
    </div>
</template>

<script>
export default {
    name: 'Header',
    data() {
        return {
        }
    },
    methods: {
    },
    mounted() {
    }
}
</script>

<style scoped lang="less">
.header {
    background-color: #409EFF;
    height: 64px;
    width: 100%;

    .logo-wrapper {
        width: 100%;
        padding: 0 4%;
        max-width: 1200px;
        margin: auto;

        .title {
            margin: 20px 0px;
            display: inline-block;
            vertical-align: middle;
            color: white;
        }
    }
}
</style>