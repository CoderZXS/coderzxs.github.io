<template>
  <div class="banner">
    <swiper :slides-per-view="1" :space-between="50" @swiper="onSwiper" @slideChange="onSlideChange" :modules="modules"
      navigation :pagination="{ clickable: true }" effect="fade" :autoplay="{ delay: 2000, disableOnInteraction: false }"
      :loop="true">
      <swiper-slide v-for="(item, index) in bannerList" :key="item.id" :virtualIndex="index">
        <div class="slide-wrapper">
          <img :src="item.imgUrl" />
          <span class="title">{{ item.desc }}</span>
        </div>
      </swiper-slide>
    </swiper>
  </div>
  <div class="bussiness">
    <h2 class="title">技术栈</h2>
    <div class="bussiness-wrapper">
      <el-row justify="start" :gutter="100">
        <el-col v-for="(item, index) in businessList" :key="item.id" class="item-col" :xs="24" :sm="24" :md="8" :lg="8"
          :xl="8">
          <div class="item-wrapper">
            <img :src="item.smallImg" class="img" />
            <div class="icon-container">
              <img :src="item.icon" class="icon" />
              <span class="text">{{ item.title }}</span>
            </div>
          </div>
        </el-col>
      </el-row>
    </div>
  </div>
  <div class="project">
    <h2 class="title">作品</h2>
    <div class="project-wrapper">
      <el-row justify="start" :gutter="100">
        <el-col v-for="(item, index) in projectList" :key="item.id" :xs="24" :sm="24" :md="8" :lg="8" :xl="8"
          class="item-col">
          <el-card shadow="hover" :body-style="{ padding: '0px' }">
            <div class="item-wrapper">
              <img :src="item.imgUrl" class="img" />
              <div class="content">
                <h3 class="title">{{ item.title }}</h3>
                <p class="desc">{{ item.desc }}</p>
              </div>
            </div>
          </el-card>
        </el-col>
      </el-row>
    </div>
  </div>
  <div class="company">
    <h2 class="title">工作经历</h2>
    <div class="company-wrapper">
      <el-timeline>
        <el-timeline-item :timestamp="item.time" placement="top" v-for="(item, index) in companyList" :key="item.id">
          <el-card>
            <h4>{{ item.name }}</h4>
            <p class="text">地址：{{ item.address }}</p>
            <p class="text">岗位：{{ item.job }}</p>
          </el-card>
        </el-timeline-item>
      </el-timeline>
    </div>
  </div>
</template>

<script>
import { Swiper, SwiperSlide } from 'swiper/vue';
import { Navigation, Pagination, A11y, EffectFade, Autoplay } from 'swiper';
import 'swiper/css';
import 'swiper/css/navigation';
import 'swiper/css/pagination';
import 'swiper/css/effect-fade';
import 'swiper/css/autoplay';
import { reqBannerList, reqBusinessList, reqProjectList, reqCompanyList } from '@/api'
import { reactive, onMounted, toRefs } from 'vue'
export default {
  name: 'Home',
  components: {
    Swiper,
    SwiperSlide,
  },
  setup() {
    const state = reactive({
      bannerList: [],
      businessList: [],
      projectList: [],
      companyList: []
    })

    const onSwiper = () => {
    };

    const onSlideChange = () => {
    };

    const getBannerList = async () => {
      const res = await reqBannerList()
      if (res.code === 200) {
        state.bannerList = res.data
      }
    }

    const getBusinessList = async () => {
      const res = await reqBusinessList()
      if (res.code === 200) {
        state.businessList = res.data
      }
    }

    const getProjectList = async () => {
      const res = await reqProjectList()
      if (res.code === 200) {
        state.projectList = res.data
      }
    }

    const getCompanyList = async () => {
      const res = await reqCompanyList()
      if (res.code === 200) {
        state.companyList = res.data
      }
    }

    onMounted(() => {
      getBannerList()
      getBusinessList()
      getProjectList()
      getCompanyList()
    })

    return {
      ...toRefs(state),
      onSwiper,
      onSlideChange,
      modules: [Navigation, Pagination, A11y, EffectFade, Autoplay],
    };
  },
}
</script>

<style lang="less" scoped>
.banner {
  height: 400px;
  width: 100%;
  overflow: hidden;

  .swiper {
    height: 100%;
    width: 100%;

    .slide-wrapper {
      height: 100%;
      width: 100%;
      position: relative;


      img {
        height: 100%;
        width: 100%;
        display: inline-block
      }

      .title {
        text-align: center;
        font-weight: 700;
        color: white;
        position: absolute;
        left: 50%;
        top: 50%;
        transform: translate(-50%, -50%);
        font-size: 40px;
      }
    }
  }
}

.bussiness {
  margin: 50px auto;
  width: 80%;

  .title {
    width: 100px;
    margin: 20px auto;
  }

  .item-col {
    margin-bottom: 10px;

    .item-wrapper {
      width: 100%;
      height: 100%;
      position: relative;

      .img {
        width: 100%;
        height: 250px;
        display: block;
        border-radius: 10px;
        box-shadow: 0px 0px 5px 2px rgba(0, 0, 0, 0.2);
        border: 0.5px solid lightgray;

        &:hover {
          box-shadow: 0px 0px 20px 10px rgba(0, 0, 0, 0.2);
        }
      }

      .icon-container {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        z-index: 1000;

        .icon {
          width: 63px;
          height: 63px;
          display: block;
        }

        .text {
          margin-top: 10px;
          color: white;
          display: block;
          font-size: 16px;
          text-align: center;
        }
      }
    }
  }
}

.project {
  margin: 50px auto;
  width: 80%;

  .title {
    width: 100px;
    margin: 20px auto;
  }

  .item-col {
    margin-bottom: 10px;

    .item-wrapper {
      width: 100%;
      height: 100%;

      .img {
        width: 100%;
        height: 250px;
        display: block;
      }

      .content {
        padding: 20px;
        width: 100%;
        box-sizing: border-box;

        .title {
          color: black;
          width: 100%;
        }

        .desc {
          margin: 10px 0px;
          width: 100%;
          color: gray;
          overflow: hidden;
          text-overflow: ellipsis;
          display: -webkit-box;
          -webkit-line-clamp: 2; //2行
          -webkit-box-orient: vertical;
        }
      }
    }
  }
}

.company {
  margin: 50px auto;
  width: 80%;

  .title {
    width: 100px;
    margin: 20px auto;
  }

  .company-wrapper {
    .text {
      margin-top: 5px;
    }
  }
}
</style>