const { defineConfig } = require('@vue/cli-service')
module.exports = defineConfig({
  transpileDependencies: true,
  lintOnSave:false,
  productionSourceMap:false,
  publicPath:'./',//设置成相对路径，打包就不会出现空白了，图片路径也应该要相应设置成相对路径。
})
